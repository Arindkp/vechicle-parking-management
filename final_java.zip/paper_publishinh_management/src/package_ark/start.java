package package_ark;
public class start {
public static void main(String args[]) throws Exception{
    new start();
}
    public start()
    { 
        loginform lg=new loginform();
        lg.setVisible(true);
    }
}
