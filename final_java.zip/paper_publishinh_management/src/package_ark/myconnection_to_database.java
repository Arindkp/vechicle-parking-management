package package_ark;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
public class myconnection_to_database {
   public static void main(String args[]) throws Exception
   {
        getConnection();
   }
   public static Connection getConnection() throws Exception
   {
	try
	{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/details","root","");
            System.out.println("Database Connected:");
            System.out.println("connection="+con);
            return con;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Error in Connecting to Database"); ;
        }	
        return null;
   }
}
